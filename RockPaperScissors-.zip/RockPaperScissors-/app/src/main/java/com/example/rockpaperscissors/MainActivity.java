package com.example.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ButtonPressed(View view) {
        RadioButton rdoPaperBtn = (RadioButton) findViewById(R.id.rdoPaper);
        RadioButton rdoRockBtn = (RadioButton) findViewById(R.id.rdoRock);
        RadioButton rdoScissorsBtn = (RadioButton) findViewById(R.id.rdoScissors);
        ImageView imageViewUserResult = (ImageView) findViewById(R.id.imageViewUserChoice);
        ImageView imageViewDevResult = (ImageView) findViewById(R.id.imageViewDeviceChoice);
        TextView resultTxt = (TextView) findViewById(R.id.textViewResult);
        //EditText userChoiceInput = (EditText) findViewById(R.id.editTextUserChoice);

        Random random = new Random();
        int r = 0, score = 0;
        boolean userChoice=false;
        String userChoiceTxt;

        String result = "";
        r = random.nextInt(3);
        //r=0 => paper
        // r=1 => rock
        //r=2 => scissors

            for (int i=0;i<3;i++){

            if (r == 0) {
                imageViewDevResult.setImageResource(R.drawable.paper);
            } else if (r == 1) {
                imageViewDevResult.setImageResource(R.drawable.rock);
            } else if (r == 2) {
                imageViewDevResult.setImageResource(R.drawable.scissors);
            }

            Log.d("wal", "" + r);

            if (rdoPaperBtn.isChecked()) {
                imageViewUserResult.setImageResource(R.drawable.paper);
                if (r == 0) {
                    result = "Draw, try again!";
                } else if (r == 1) {
                    result = "You won this time.";
                    score++;
                } else if (r == 2) {
                    result = "You lost this time.";
                    score--;
                }
            } else if (rdoRockBtn.isChecked()) {
                imageViewUserResult.setImageResource(R.drawable.rock);
                if (r == 0) {
                    result = "You lost this time.";
                    score--;
                } else if (r == 1) {
                    result = "Draw, try again!";
                } else if (r == 2) {
                    result = "You won this time.";
                    score++;
                }
            } else if (rdoScissorsBtn.isChecked()) {
                imageViewUserResult.setImageResource(R.drawable.scissors);
                if (r == 0) {
                    result = "You won this time.";
                    score++;
                } else if (r == 1) {
                    result = "You lost this time.";
                    score--;
                } else if (r == 2) {
                    result = "Draw, try again!";
                }
            }
            resultTxt.setText(result + " the score is: " + score);
        }
    }
}
